const CONFIG = {
    TILE_SIZE: 20,
    GAME_SPEED: 90,
    INITIAL_SNAKE: [
        {x: 5, y: 5},
        {x: 6, y: 5}
    ],
    INITIAL_APPLES: 5,

    COLORS: {
        background: "#f0f0ff",
        grid: "#36802d",
        snakeHead: "#1019a0",
        snakeBody: "#7aa8e4",
        apple: "#e03131"
    }
};

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const overlay = document.getElementById("overlay");
const overlayTitle = document.getElementById("overlay-title");
const overlayText = document.getElementById("overlay-text");

const startBtn = document.getElementById("start-btn");
const scoreDisplay = document.getElementById("score");
const modeDisplay = document.getElementById("mode");

const GRID_WIDTH = canvas.width / CONFIG.TILE_SIZE;
const GRID_HEIGHT = canvas.height / CONFIG.TILE_SIZE;

let snake = [];
let apples = [];

let dirX = 0;
let dirY = 0;

let nextX = 0;
let nextY = 0;

let score = 0;

let mode = "demo";

let isRunning = false;
let isPaused = false;

let lastTime = 0;
let animationFrameId;

function setDirection(x, y) {

    if (x === -dirX && y === -dirY) return;

    nextX = x;
    nextY = y;
}

document.addEventListener("keydown", event => {

    const keys = {
        ArrowUp: [0, -1],
        ArrowDown: [0, 1],
        ArrowLeft: [-1, 0],
        ArrowRight: [1, 0],

        w: [0, -1],
        s: [0, 1],
        a: [-1, 0],
        d: [1, 0]
    };

    const key = event.key.length === 1
        ? event.key.toLowerCase()
        : event.key;

    if (keys[key]) {

        event.preventDefault();

        if (mode === "player" && isRunning && !isPaused) {
            setDirection(...keys[key]);
        }
    }

    if (event.code === "Space") {
        event.preventDefault();
        togglePause();
    }
});

// Touch-Steuerung

document.querySelectorAll("[data-dir]").forEach(button => {

    button.addEventListener("click", () => {

        if (mode !== "player" || !isRunning || isPaused) return;

        const directions = {
            up: [0, -1],
            down: [0, 1],
            left: [-1, 0],
            right: [1, 0]
        };

        setDirection(...directions[button.dataset.dir]);
    });

});

function createApple() {

    const freeCells = [];

    for (let y = 0; y < GRID_HEIGHT; y++) {
        for (let x = 0; x < GRID_WIDTH; x++) {

            const occupied = snake.some(
                s => s.x === x && s.y === y
            );

            const appleExists = apples.some(
                a => a.x === x && a.y === y
            );

            if (!occupied && !appleExists) {
                freeCells.push({x, y});
            }
        }
    }

    if (!freeCells.length) return null;

    return freeCells[
        Math.floor(Math.random() * freeCells.length)
    ];
}

function initApples() {

    apples = [];

    for (let i = 0; i < CONFIG.INITIAL_APPLES; i++) {

        const apple = createApple();

        if (apple) apples.push(apple);
    }
}

function drawBackground() {

    const size = CONFIG.TILE_SIZE;

    ctx.fillStyle = CONFIG.COLORS.background;

    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = CONFIG.COLORS.grid;
    ctx.lineWidth = 0.5;

    for (let x = 0; x <= canvas.width; x += size) {

        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
    }

    for (let y = 0; y <= canvas.height; y += size) {

        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
    }
}

function drawSnake() {

    const size = CONFIG.TILE_SIZE;

    snake.forEach((segment, i) => {

        ctx.fillStyle = i === 0
            ? CONFIG.COLORS.snakeHead
            : CONFIG.COLORS.snakeBody;

        ctx.globalAlpha = 1 - (i / snake.length) * 0.4;

        ctx.beginPath();

        ctx.roundRect(
            segment.x * size + 1,
            segment.y * size + 1,
            size - 2,
            size - 2,
            5
        );

        ctx.fill();
    });

    ctx.globalAlpha = 1;
}

function drawApples() {

    const size = CONFIG.TILE_SIZE;

    apples.forEach(apple => {

        const cx = apple.x * size + size / 2;
        const cy = apple.y * size + size / 2;

        ctx.fillStyle = CONFIG.COLORS.apple;

        ctx.beginPath();
        ctx.arc(cx, cy, 7, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#ff8787";

        ctx.beginPath();
        ctx.arc(cx - 2, cy - 3, 2, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = "#5a3d28";
        ctx.lineWidth = 2;

        ctx.beginPath();
        ctx.moveTo(cx, cy - 6);
        ctx.lineTo(cx + 2, cy - 10);
        ctx.stroke();
    });
}

function drawScore() {

    scoreDisplay.textContent = "Punkte: " + score;

}

function autoPilot() {

    if (!apples.length) return;

    const head = snake[0];

    const directions = [
        {x: 1, y: 0},
        {x: -1, y: 0},
        {x: 0, y: 1},
        {x: 0, y: -1}
    ];

    const target = apples.reduce((nearest, apple) => {

        const distance =
            Math.abs(head.x - apple.x) +
            Math.abs(head.y - apple.y);

        return !nearest || distance < nearest.distance
            ? {apple, distance}
            : nearest;

    }, null).apple;

    const safeDirections = directions.filter(dir => {

        if (dir.x === -dirX && dir.y === -dirY) {
            return false;
        }

        const next = {
            x: head.x + dir.x,
            y: head.y + dir.y
        };

        if (
            next.x < 0 ||
            next.x >= GRID_WIDTH ||
            next.y < 0 ||
            next.y >= GRID_HEIGHT
        ) return false;

        const eating = apples.some(
            a => a.x === next.x && a.y === next.y
        );

        const body = eating
            ? snake
            : snake.slice(0, -1);

        return !body.some(
            s => s.x === next.x && s.y === next.y
        );

    });

    if (!safeDirections.length) return;

    safeDirections.sort((a, b) => {

        const distanceA =
            Math.abs(head.x + a.x - target.x) +
            Math.abs(head.y + a.y - target.y);

        const distanceB =
            Math.abs(head.x + b.x - target.x) +
            Math.abs(head.y + b.y - target.y);

        return distanceA - distanceB;

    });

    nextX = safeDirections[0].x;
    nextY = safeDirections[0].y;
}

function checkCollision(head, eating) {

    if (
        head.x < 0 ||
        head.x >= GRID_WIDTH ||
        head.y < 0 ||
        head.y >= GRID_HEIGHT
    ) return true;

    const body = eating
        ? snake
        : snake.slice(0, -1);

    return body.some(
        s => s.x === head.x && s.y === head.y
    );
}

function move() {

    dirX = nextX;
    dirY = nextY;

    if (dirX === 0 && dirY === 0) return;

    const newHead = {
        x: snake[0].x + dirX,
        y: snake[0].y + dirY
    };

    const appleIndex = apples.findIndex(
        a => a.x === newHead.x && a.y === newHead.y
    );

    const eating = appleIndex !== -1;

    if (checkCollision(newHead, eating)) {

        gameOver();
        return;
    }

    snake.unshift(newHead);

    if (eating) {

        score += 10;

        apples.splice(appleIndex, 1);

        const apple = createApple();

        if (apple) apples.push(apple);

    } else {

        snake.pop();
    }

    drawScore();

    if (snake.length >= GRID_WIDTH * GRID_HEIGHT) {
        gameOver();
    }
}

function gameOver() {

    isRunning = false;

    overlayTitle.textContent = "Game Over!";
    overlayText.textContent = "Deine Punkte: " + score;

    startBtn.textContent = "Nochmal spielen";

    overlay.classList.remove("hidden");
}

function render() {

    drawBackground();
    drawApples();
    drawSnake();
    drawScore();
}

function gameLoop(time) {

    if (!isRunning || isPaused) return;

    animationFrameId = requestAnimationFrame(gameLoop);

    const elapsed = time - lastTime;

    if (elapsed < CONFIG.GAME_SPEED) return;

    lastTime = time - (elapsed % CONFIG.GAME_SPEED);

    if (mode === "demo") {
        autoPilot();
    }

    move();

    if (isRunning) {
        render();
    }
}

function startGame() {

    cancelAnimationFrame(animationFrameId);

    snake = CONFIG.INITIAL_SNAKE.map(
        s => ({...s})
    );

    dirX = 0;
    dirY = 0;

    nextX = 0;
    nextY = 0;

    score = 0;

    isPaused = false;
    isRunning = true;

    initApples();

    overlay.classList.add("hidden");

    document.getElementById("pause-btn").textContent = "⏸ Pause";

    render();

    lastTime = performance.now();

    animationFrameId = requestAnimationFrame(gameLoop);
}

function setMode(newMode) {

    mode = newMode;

    document.getElementById("demo-btn")
        .classList.toggle("active", mode === "demo");

    document.getElementById("player-btn")
        .classList.toggle("active", mode === "player");

    modeDisplay.textContent =
        mode === "demo"
            ? "Modus: Demo 🤖"
            : "Modus: Spieler 🎮";

    overlayTitle.textContent =
        mode === "demo"
            ? "Demo-Modus"
            : "Selber spielen";

    overlayText.textContent =
        mode === "demo"
            ? "Die KI spielt automatisch!"
            : "Steuere die Schlange selbst!";

    startBtn.textContent = "Spiel starten";

    overlay.classList.remove("hidden");

    startGame();
}

document.getElementById("demo-btn").addEventListener(
    "click",
    () => setMode("demo")
);

document.getElementById("player-btn").addEventListener(
    "click",
    () => setMode("player")
);

function togglePause() {

    if (!isRunning) return;

    isPaused = !isPaused;

    const button = document.getElementById("pause-btn");

    if (isPaused) {

        cancelAnimationFrame(animationFrameId);

        button.textContent = "▶ Weiter";

        overlayTitle.textContent = "Pause";
        overlayText.textContent = "Spiel angehalten";

        startBtn.textContent = "Weiter spielen";

        overlay.classList.remove("hidden");

    } else {

        overlay.classList.add("hidden");

        button.textContent = "⏸ Pause";

        lastTime = performance.now();

        animationFrameId = requestAnimationFrame(gameLoop);
    }
}

document.getElementById("pause-btn")
    .addEventListener("click", togglePause);

document.getElementById("restart-btn")
    .addEventListener("click", startGame);

startBtn.addEventListener("click", () => {

    if (isPaused && isRunning) {
        togglePause();
    } else {
        startGame();
    }

});

setMode("demo");